# REPO MAP (Generated in Stage 00)

Fill using repo‑truth commands (no guessing). Keep it short and accurate.

## Repo structure
- Top‑level directories:
- App directory (frontend):
- API/server directory (if any):
- Where `package.json` lives:
- Where config lives (vite/next/tailwind/tsconfig):

## Scripts (from package.json)
- dev:
- build:
- lint:
- test:
- e2e (if any):

## Environment keys (from repo search)
- Supabase (url/anon/etc):
- Other APIs:
- Payments:
- Analytics/monitoring:

## Confirmed critical paths
- App entry (router/layout):
- Feature under work (current stage):
- API routes / server handlers:
- DB client init:
- Auth middleware/guards:
- Deploy config (vercel/netlify/etc):

## Commands used
```bash
# paste commands + short results
```
